package com.SWEPJ;

public class Approve {
    Approve() {
        System.out.println("Approve working");
    }
}
