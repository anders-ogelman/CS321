package com.SWEPJ;

public class Entry {
    Entry() {
        System.out.println("Entry still working");
    }
}
