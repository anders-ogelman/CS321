package com.SWEPJ;

public class Review {
    Review() {
        System.out.println("Review working");
    }
}
